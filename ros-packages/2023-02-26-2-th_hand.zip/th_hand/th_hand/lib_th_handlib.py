#!/usr/bin/env python3
import os
import sys
import rclpy
from ament_index_python.packages import get_package_share_directory
from gazebo_msgs.srv import SpawnEntity


class TH_Finger():
    def __init__(self, name):
        # Joint names that are supposed to match Gazebo joints
        self.name = name
        self.joint_names = [name + "0_2_" + name + "1",
                            name + "1_2_" + name + "2",
                            name + "2_2_" + name + "3",
                            ]
        # Panning movement of the finger
        self.abduction = 0
        # bending movement of the finger
        self.flexion = [0, 0, 0]
        # Phalnage lengths of the finger
        self.lengths = [1, 1, 1]

    def move(abduction, flexion):
        pass


class TH_Hand():
    def __init__(self):
        self.joint_names = []
        self.fingers = []

        # Setup fingers of the hand
        def create_finger(name):
            self.joint_names.append("wrist_2_" + name + "0")
            self.fingers.append(TH_Finger(name))

        create_finger("thumb")
        create_finger("index")
        create_finger("middle")
        create_finger("ring")
        create_finger("pinky")

        # TODO: Setup these to be ROS compatible matrices
        self.transformation = None

    def print(self):
        print(f"Hand Transform: {self.transformation}")
        print("Finger: abduction/flexion")
        for finger in self.fingers:
            print(f"- {finger.name}: {finger.abduction} / {finger.flexion}")


def TH_SpawnRobot(path, name, namespace, pos=[0, 0, 0]):
    """
    Spawning arbitrary gazebo .sdf robots from path
    """
    # Start node
    rclpy.init()
    node = rclpy.create_node("entity_spawner")

    node.get_logger().info(
        'Creating Service client to connect to `/spawn_entity`')
    client = node.create_client(SpawnEntity, "/spawn_entity")

    node.get_logger().info("Connecting to `/spawn_entity` service...")
    if not client.service_is_ready():
        client.wait_for_service()
        node.get_logger().info("...connected!")

    # Set data for spawn request
    sdf_file_path = path
    request = SpawnEntity.Request()
    request.name = name
    request.xml = open(sdf_file_path, 'r').read()
    request.robot_namespace = namespace
    request.initial_pose.position.x = float(pos[0])
    request.initial_pose.position.y = float(pos[1])
    request.initial_pose.position.z = float(pos[2])

    node.get_logger().info("Sending service request to `/spawn_entity`")
    future = client.call_async(request)
    rclpy.spin_until_future_complete(node, future)
    if future.result() is not None:
        print('response: %r' % future.result())
    else:
        raise RuntimeError(
            'exception while calling service: %r' % future.exception())

    node.get_logger().info("Done! Shutting down node.")
    node.destroy_node()
    rclpy.shutdown()


# ================================================================================
# TESTS
# ================================================================================


def _TH_HandClassTest():
    hand = TH_Hand()
    print("Hand Joints:")
    print(f"{hand.joint_names}")
    print("Finger Joints:")
    for finger in hand.fingers:
        print(f"- {finger.joint_names}")
    hand.print()


def _TH_ROSNodeSpawnTest():
    # TODO: Fix so it can find its own package path!
    path = "/home/th/ros2_colcon_ws/src/th_hand/models/th_hand_v2/model.sdf"
    # path = os.path.join(
    #    get_package_share_directory("th_hand"), "models",
    #    "th_hand_v2", "model.sdf")
    TH_SpawnRobot(path, "mah_fookin_th_hand", "th_hand_namespace", pos=[1, 1, 1])


if __name__ == "__main__":
    print("--------------------------------------------")
    print("This File is not meant to be called as main!")
    print("---")
    print("---")
    # _TH_HandClassTest()
    # _TH_ROSNodeSpawnTest()
