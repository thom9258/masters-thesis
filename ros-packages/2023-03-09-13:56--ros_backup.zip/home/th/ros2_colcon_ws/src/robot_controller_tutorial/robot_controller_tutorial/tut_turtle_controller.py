#!/usr/bin/env python3

from functools import partial

import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
# Service client import
from turtlesim.srv import SetPen

class CLSNode(Node):
    def __init__(self, name):
        super().__init__(name)
        self.get_logger().info("ROS2 Initialized Node.")
        self.name = name

        self.velocity_publisher = self.create_publisher(Twist,
                                                        "/turtle1/cmd_vel",
                                                        10)

        self.pose_subscriber = self.create_subscription(Pose,
                                                        "/turtle1/pose",
                                                        self.pose_callback,
                                                        10)

        self.prev_x = 0

    def pose_callback(self, pose: Pose):
        # self.get_logger().info(f"x,y = {pose.x}, {pose.y}")
        msg = Twist()
        if pose.x > 9.0 or pose.x < 2.0 or pose.y > 9.0 or pose.y < 2.0:
            msg.linear.x = 1.0
            msg.angular.z = 0.9
        else:
            msg.linear.x = 5.0
            msg.angular.z = 0.0
        self.velocity_publisher.publish(msg)

        # Here we call our service, but notice its only when nessecary!
        # Services are resource heavy!
        if pose.x > 5.5 and self.prev_x <= 5.5:
            self.prev_x = pose.x
            self.service_set_pen(255, 0, 0, 3, 0)
            self.get_logger().info("Service set color to red.")
        elif pose.x <= 5.5 and self.prev_x > 5.5:
            self.prev_x = pose.x
            self.service_set_pen(0, 255, 0, 3, 0)
            self.get_logger().info("Service set color to green.")

    def service_set_pen(self, r, g, b, width, off):
        # We create a client and wait for it to get access to the service
        client = self.create_client(SetPen, "turtle1/set_pen")
        while not client.wait_for_service(1.0):
            self.get_logger().warn("Waiting for service...")

        # We create the service request
        request = SetPen.Request()
        request.r = r
        request.g = g
        request.b = b
        request.width = width
        request.off = off

        # We call it async (non-blocking) with our request
        future = client.call_async(request)

        # We add a callback for when the call is replied
        future.add_done_callback(partial(self.callback_set_pen))

    def callback_set_pen(self, future):
        try:
            response = future.result()
        except Exception as e:
            self.get_logger().error(f"Service call failed -> {e}")


def main(args=None):
    rclpy.init(args=args)

    node = CLSNode("ClosedLoopSystem")
    # Keep node alive until killed
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
