#!/usr/bin/env python3
import rclpy
from rclpy.node import Node


class MyNode(Node):
    def __init__(self, name):
        super().__init__(name)
        self.name = name
        self.counter = 0
        self.get_logger().info("ROS2 Initialized Node.")
        self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        self.get_logger().info(f"Timer Tick ({self.counter}) Called.")
        self.counter += 1


def main(args=None):
    rclpy.init(args=args)

    node = MyNode("Timer")
    # Keep node alive until killed
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
