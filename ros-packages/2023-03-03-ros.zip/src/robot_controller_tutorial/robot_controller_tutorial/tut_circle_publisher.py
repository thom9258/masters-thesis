#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

# We want to publish a Twist message from the geometry package
from geometry_msgs.msg import Twist


class DrawCircleNode(Node):
    def __init__(self, name):
        super().__init__(name)
        self.get_logger().info("ROS2 Initialized Node.")
        self.name = name
        # The turtle bot listens to all messages created this way:
        self.velocity_publisher = self.create_publisher(Twist,
                                                        "/turtle1/cmd_vel",
                                                        10)
        # Commands: Type, File, queue buffer size
        self.timer = self.create_timer(0.5, self.send_velocity_command)

    def send_velocity_command(self):
        msg = Twist()
        msg.linear.x = 2.0
        msg.angular.z = 1.0
        self.velocity_publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = DrawCircleNode("Circle_Drawer")
    # Keep node alive until killed
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
