#!/usr/bin/env python3

# Robot Controlling
import rclpy
from rclpy.node import Node

# Different messages for control
from std_msgs.msg import Float64
from std_srvs.srv import SetBool
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray

# Robot Spawning
from gazebo_msgs.srv import SpawnEntity

# from .lib_th_handlib import TH_SpawnRobot


def TH_SpawnRobot(path, name, namespace, pos=[0, 0, 0]):
    """
    Spawning arbitrary gazebo .sdf robots from path
    Expects rclpy.init() to be already called!
    """
    # Start node
    node = rclpy.create_node("entity_spawner")

    node.get_logger().info(
        'Creating Service client to connect to `/spawn_entity`')
    client = node.create_client(SpawnEntity, "/spawn_entity")

    node.get_logger().info("Connecting to `/spawn_entity` service...")
    if not client.service_is_ready():
        client.wait_for_service()
        node.get_logger().info("...connected!")

    # Set data for spawn request
    sdf_file_path = path
    request = SpawnEntity.Request()
    request.name = name
    request.xml = open(sdf_file_path, 'r').read()
    request.robot_namespace = namespace
    request.initial_pose.position.x = float(pos[0])
    request.initial_pose.position.y = float(pos[1])
    request.initial_pose.position.z = float(pos[2])

    node.get_logger().info("Sending service request to `/spawn_entity`")
    future = client.call_async(request)
    rclpy.spin_until_future_complete(node, future)
    if future.result() is not None:
        print('response: %r' % future.result())
    else:
        raise RuntimeError(
            'exception while calling service: %r' % future.exception())

    node.get_logger().info(f"Done! Shutting down Spawner for [{name}]")
    node.destroy_node()


class TH_Hand(Node):
    def __init__(self, name, pos=[0, 0, 1]):
        super().__init__(name)
        self.name = name
        self.counter = 0
        self.get_logger().info("ROS2 Initialized Hand Simulator Node.")
        path = "/home/th/ros2_colcon_ws/src/th_hand/models/th_hand_v2/model.sdf"
        TH_SpawnRobot(path, name, "th_hand_namespace", pos)

        self.joint_positions = [0.0, 0.0]
        self.joint_velocities = [0.0, 0.0]
        self.joint_efforts = [0.0, 0.0]

        # self.joint_publisher = self.create_publisher(JointState,
        #                                              f"/{name}/index2_2_index3/command",
        #                                              #f"/{name}/wrist_2_index0/joint_states",
        #                                              10)

        # self.timer = self.create_timer(0.1, self.timer_callback)

        publish_target = f"/{name}/index0_2_index1/command"
        self.get_logger().info(f"Publishing to {publish_target}")
        self.velocity_publisher = self.create_publisher(Float64,
                                                        publish_target,
                                                        10)
        # Start with rotation
        velocity_msg = Float64()
        velocity_msg.data = float(10)  # set the desired velocity
        self.velocity_publisher.publish(velocity_msg)



        service_name = f"/{name}/joint1_rotate"
        self.get_logger().info(f"Client node created on: {service_name}")
        self.rotate_service = self.create_service(SetBool,
                                                  service_name,
                                                  self.rotate_callback)

    def rotate_callback(self, request, response):
        """
        Is callable using the following terminal command:
        ros2 service call /my_dahm_th_hand/joint1_rotate std_srvs/SetBool "{data: true}"
        """
        if request.data:
            # Start rotating the joint at a constant velocity
            velocity_msg = Float64()
            velocity_msg.data = float(10)  # set the desired velocity
            self.velocity_publisher.publish(velocity_msg)
            response.success = True
            response.message = 'Joint rotation started'
        else:
            # Stop rotating the joint
            velocity_msg = Float64()
            velocity_msg.data = 0.0
            self.velocity_publisher.publish(velocity_msg)
            response.success = True
            response.message = 'Joint rotation stopped'
        return response

#   def timer_callback(self):
#       self.joint_positions[0] += 0.1
#       self.joint_positions[1] += 0.1
#       self.joint_velocities[0] += 0.5
#       self.joint_velocities[1] += 0.5
#       self.joint_efforts = [2.0, 2.0]
#       msg = JointState()
#       msg.name = ['joint1', 'joint2']
#       msg.velocity = self.joint_velocities
#       msg.effort = self.joint_efforts
#       self.joint_publisher.publish(msg)
#       self.get_logger().info(f"Published {msg}")


def main(args=None):
    rclpy.init(args=args)
    node = TH_Hand("my_dahm_th_hand")
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
