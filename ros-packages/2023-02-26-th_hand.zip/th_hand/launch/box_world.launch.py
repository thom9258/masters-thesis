#!/usr/bin/python3
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, Command


from launch_ros.actions import Node


def generate_launch_description():
    plugins_dir = "plugins"
    worlds_dir = "worlds"
    models_dir = "models"
    ros_package_name = "th_hand"
    world_name = "box_world.world"

    # Get the path to the Gazebo world file
    #world_file = os.path.join(get_package_share_directory(ros_package_name), worlds_dir, world_name)
    world_file = '/home/th/ros2_colcon_ws/src/th_hand/worlds/box_world.world'
    # Gazebo launch
    pkg_share_dir = get_package_share_directory(ros_package_name)
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gazebo.launch.py'),
        )
    )

    # Description: Environment launch file
    environment = DeclareLaunchArgument(
        'world',
        default_value=[os.path.join(pkg_share_dir, 'worlds', world_name), ''],
        description='MY DESCRIPTION, BIG WORLD, BIG DREAMS')

    th_hand_dummy = Node(package="th_hand", executable="th_dummy_hand")

    # Create the launch description and populate it with nodes and arguments
    ld = LaunchDescription([
        environment,
        gazebo,

        # Nodes
        th_hand_dummy,

        # Other launch files

    ])

    return ld
