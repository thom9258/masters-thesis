#!/usr/bin/env python3
import rclpy
from launch_ros.actions import Node as LaunchNode
from launch.substitutions import LaunchConfiguration
from rclpy.node import Node


class TH_Hand(Node):
    def __init__(self, name):
        super().__init__(name)
        self.name = name
        self.counter = 0
        self.get_logger().info("ROS2 Initialized Hand Simulator Node.")

        # Constants for paths to different files and folders
        robot_name_in_model = 'th_goddahm hand'
        sdf_model_path = '/home/th/ros2_colcon_ws/src/th_hand/models/th_hand_v2/model.sdf'
        # Pose where we want to spawn the robot
        spawn_x_val = '0.0'
        spawn_y_val = '0.0'
        spawn_z_val = '0.0'
        spawn_yaw_val = '0.0'

        sdf_model = LaunchConfiguration('sdf_model')
        spawn_entity_cmd = LaunchNode(package='gazebo_ros',
                                      executable='spawn_entity.py',
                                      arguments=['-entity', robot_name_in_model,
                                                 '-file', sdf_model,
                                                 '-x', spawn_x_val,
                                                 '-y', spawn_y_val,
                                                 '-z', spawn_z_val,
                                                 '-Y', spawn_yaw_val],
                                      output='screen')
 

def main(args=None):
    rclpy.init(args=args)

    node = TH_Hand("a_fookin_th_hand")
    # Keep node alive until killed
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
